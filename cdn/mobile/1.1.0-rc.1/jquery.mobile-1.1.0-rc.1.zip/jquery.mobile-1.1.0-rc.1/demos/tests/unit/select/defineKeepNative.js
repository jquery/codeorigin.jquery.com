$(document).bind("mobileinit", function() {
	$.mobile.page.prototype.options.keepNative = "select.should-be-native";
});


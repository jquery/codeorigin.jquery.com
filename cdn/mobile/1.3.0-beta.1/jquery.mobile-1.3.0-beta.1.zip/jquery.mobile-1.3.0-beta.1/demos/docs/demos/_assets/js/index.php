<?php
$type = 'text/javascript';
$files = array(
	'jqm-demos.js',
	'view-source.js'
);

require_once('../../../../combine.php');
